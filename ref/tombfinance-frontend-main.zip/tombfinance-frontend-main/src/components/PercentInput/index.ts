export { default } from './PercentInput';
