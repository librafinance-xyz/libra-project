# DarkCrypto.Finance

[![Twitter Follow](https://img.shields.io/twitter/follow/darkcryptofi?label=Follow)](https://twitter.com/DarkCryptoFi)

DarkCrypto Finance is inspired and forked from [Tomb Finance](https://tomb.finance).

## Contract Addresses
| Contract  | Address |
| ------------- | ------------- |
| DarkCrypto (DARK) | https://cronos.crypto.org/explorer/address/0x83b2AC8642aE46FC2823Bc959fFEB3c1742c48B5/contracts |
| DarkCrypto Share (SKY) | https://cronos.crypto.org/explorer/address/0xf5e5271432089254288F47d6F2CFcfE066377900/contracts |
| DarkCrypto Bond (LIGHT) |  |
| DarkRewardPool | https://cronos.crypto.org/explorer/address/0x28d81863438F25b6EC4c9DA28348445FC5E44196/contracts |


#### Community channels:

- Telegram: https://t.me/darkcryptofi 
- Twitter: https://twitter.com/DarkCryptoFi
- GitHub: https://github.com/darkcryptofi/darkcrypto-contracts

## Disclaimer

Use at your own risk. This product is perpetually in beta.

_© Copyright 2022, [DarkCrypto.Finance](https://DarkCrypto.Finance)_
