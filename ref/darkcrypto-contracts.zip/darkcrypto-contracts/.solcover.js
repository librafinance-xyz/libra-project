module.exports = {
  skipFiles: [
    'lib',
    'test',
    'token',
    'interfaces',
    'distributor',
    'distribution',
    'Timelock.sol',
    'Migrations.sol',
    'Distributor.sol',
  ]
}
