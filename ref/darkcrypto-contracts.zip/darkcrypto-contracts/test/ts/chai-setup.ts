import chaiModule from 'chai';
import {waffleChai} from '@ethereum-waffle/chai';

chaiModule.use(waffleChai);
export = chaiModule;
